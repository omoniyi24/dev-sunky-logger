import logging


class error:

    def error(msg):
        return logging.error(msg)
