import logging


class warning:

    def warn(msg):
        return logging.warning(msg)